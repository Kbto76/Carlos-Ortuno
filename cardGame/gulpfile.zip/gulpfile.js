const { watch, series } = require('gulp');
const rollup = require('rollup');
const gulp = require('gulp');
const clean = require('gulp-clean');
const browsersynch = require('browser-sync');
const server = browsersynch.create();

exports.bundle = () => {
    console.log('GULP - Running bundle function');
}

function reloadServer(cd) {
    server.reload()
    cd()
}

function runRerver() {
    server.init({
        server: {
            baseDir: "."
        }
    });
}

function watchingFiles() { //si se hace algun cambio se refresca el servidor
    watch('js/', { events: 'all' }, reloadServer())
    watch('css/', { events: 'all' }, reloadServer())
    watch('*.html', reloadServer())
}

exports.play = () => {
    console.log('GULP - Running game....');
    runRerver();
    watchingFiles();
}

gulp.task('clean', () => {
    return gulp.src('node_modules').pipe(clean());
})